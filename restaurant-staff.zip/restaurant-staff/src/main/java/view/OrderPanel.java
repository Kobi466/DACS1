package view;

import controller.OrderController;
import dto.CustomerDTO;
import dto.MessageDTO;
import dto.OrderSummaryDTO;
import socket.GlobalResponseRouter;
import socket.SocketClient;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class OrderPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private final OrderController controller;

    public OrderPanel() {
        this.controller = new OrderController(this);
        setupUI();
        registerListeners();
        controller.loadOrders();
    }

    private void setupUI() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new Object[]{"ID", "Khách", "Thời gian", "Trạng thái"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    public void updateOrderTable(List<OrderSummaryDTO> orders) {
        SwingUtilities.invokeLater(() -> {
            model.setRowCount(0);
            for (OrderSummaryDTO order : orders) {
                model.addRow(new Object[]{
                        order.getCustomerName(),
                        order.getCustomerPhone(),
                        order.getOrderDate(),
                        order.getStatus().name()
                });
            }
        });
    }

    public void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
    private void registerListeners() {
        GlobalResponseRouter.registerHandler(response -> {
            switch (response.getStatus()) {
                case "GET_ORDERS_SUCCESS" -> {
                    List<OrderSummaryDTO> orders = (List<OrderSummaryDTO>) response.getData();
                    updateOrderTable(orders); // ✅ Chỉ cập nhật bảng
                    System.out.println("✅ Đã nhận danh sách đơn hàng.");
                }
                default -> System.out.println("⚠️ Không hiểu phản hồi: " + response.getStatus());
            }
        });
    }
}
