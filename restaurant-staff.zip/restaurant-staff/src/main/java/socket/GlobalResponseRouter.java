package socket;

import com.fasterxml.jackson.core.JsonProcessingException;
import network.JsonResponse;

import java.util.function.Consumer;

public class GlobalResponseRouter {
    private static Consumer<JsonResponse> handler;

    public static void registerHandler(Consumer<JsonResponse> h) {
        handler = h;
    }

    public static void dispatch(JsonResponse response) throws JsonProcessingException {
        if (handler != null) handler.accept(response);
    }
}
